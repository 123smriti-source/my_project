package com.restaurant.frontpage;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

import com.restaurant.dao.AdminDaoImp;
import com.restaurant.dao.BillingExecutiveDaoImp;
import com.restaurant.dao.FoodDaoImp;
import com.restaurant.dao.WaiterDaoImp;
import com.restaurant.pojo.Admin;
import com.restaurant.pojo.BillingExecutive;
import com.restaurant.pojo.Food;
import com.restaurant.pojo.Waiter;
import com.restaurant.utility.Constants.IsACTIVE;
import javax.swing.JPasswordField;


public class BillingExecutiveCrud extends JFrame {

	private JPanel contentPane;
	private JTextField eId;
	private JTextField eName;
	private JTextField eUsername;
	private JTextField ePhone;
	private JPasswordField ePassword;
	private JPasswordField eCPassword;
	private JTextField eDoj;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					BillingExecutiveCrud frame = new BillingExecutiveCrud();
					frame.setVisible(true);
					frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public BillingExecutiveCrud() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1263, 710);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(0, 0, 0), 3));
		panel.setBackground(new Color(32, 178, 170));
		panel.setBounds(0, 0, 1365, 75);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Billing   Executive   Registration");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 40));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(10, 11, 1340, 53);
		panel.add(lblNewLabel);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panel_1.setBackground(new Color(255, 128, 0));
		panel_1.setBounds(0, 86, 1365, 700);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel v3 = new JLabel("");
		v3.setBounds(517, 202, 184, 25);
		panel_1.add(v3);
		
		JLabel lblNewLabel_1 = new JLabel("Add / Update /Delete Executive");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 30));
		lblNewLabel_1.setBounds(415, 11, 526, 51);
		panel_1.add(lblNewLabel_1);
		
		JLabel id = new JLabel("Executive Id:");
		id.setFont(new Font("Tahoma", Font.BOLD, 20));
		id.setBounds(149, 95, 134, 25);
		panel_1.add(id);
		
		eId = new JTextField();
		eId.setColumns(10);
		eId.setBounds(294, 95, 213, 25);
		panel_1.add(eId);
		
		JLabel v1 = new JLabel("");
		v1.setBounds(517, 145, 146, 25);
		panel_1.add(v1);
		
		JLabel v4 = new JLabel("");
		v4.setBounds(1064, 202, 146, 25);
		panel_1.add(v4);
		
		JLabel lblNewLabel_2 = new JLabel("Enter Executive Id to fetch the Executive");
		lblNewLabel_2.setBounds(525, 95, 229, 23);
		panel_1.add(lblNewLabel_2);
		
		JButton back = new JButton("Back");
		back.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				BillExecutivePage  f = new BillExecutivePage();
				f.setVisible(true);
				f.setExtendedState(JFrame.MAXIMIZED_BOTH);
				dispose();
			}
		});
		back.setForeground(new Color(32, 178, 170));
		back.setFont(new Font("Tahoma", Font.BOLD, 15));
		back.setBackground(new Color(255, 255, 255));
		back.setBounds(0, 0, 89, 23);
		panel_1.add(back);
		
		JPanel panel_1_1 = new JPanel();
		panel_1_1.setLayout(null);
		panel_1_1.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panel_1_1.setBackground(new Color(255, 128, 0));
		panel_1_1.setBounds(0, 73, 1365, 700);
		panel_1.add(panel_1_1);
		
		JLabel v2 = new JLabel("");
		v2.setBounds(1061, 79, 146, 25);
		panel_1_1.add(v2);
		
		JLabel name = new JLabel("Name:");
		name.setFont(new Font("Tahoma", Font.BOLD, 20));
		name.setBounds(205, 79, 75, 25);
		panel_1_1.add(name);
		
		eName = new JTextField();
		eName.setColumns(10);
		eName.setBounds(291, 79, 213, 25);
		panel_1_1.add(eName);
		
		JLabel username = new JLabel("Username:");
		username.setFont(new Font("Tahoma", Font.BOLD, 20));
		username.setBounds(705, 79, 122, 25);
		panel_1_1.add(username);
		
		eUsername = new JTextField();
		eUsername.setColumns(10);
		eUsername.setBounds(838, 79, 213, 25);
		panel_1_1.add(eUsername);
		
		JLabel phone = new JLabel("Phone No.:");
		phone.setFont(new Font("Tahoma", Font.BOLD, 20));
		phone.setBounds(171, 136, 109, 25);
		panel_1_1.add(phone);
		
		ePhone = new JTextField();
		ePhone.setColumns(10);
		ePhone.setBounds(291, 136, 213, 25);
		panel_1_1.add(ePhone);
		
		JLabel address = new JLabel("Address:");
		address.setFont(new Font("Tahoma", Font.BOLD, 20));
		address.setBounds(726, 136, 101, 25);
		panel_1_1.add(address);
		
		JLabel v4_1 = new JLabel("");
		v4_1.setBounds(1061, 136, 146, 25);
		panel_1_1.add(v4_1);
		
		JTextArea eAddress = new JTextArea();
		eAddress.setBounds(838, 136, 213, 66);
		panel_1_1.add(eAddress);
		
		JLabel adminPassword = new JLabel("Password:");
		adminPassword.setFont(new Font("Tahoma", Font.BOLD, 20));
		adminPassword.setBounds(171, 224, 109, 25);
		panel_1_1.add(adminPassword);
		
		JLabel v5 = new JLabel("");
		v5.setBounds(514, 224, 146, 25);
		panel_1_1.add(v5);
		
		JLabel cPass = new JLabel("Confirm Pass:");
		cPass.setFont(new Font("Tahoma", Font.BOLD, 20));
		cPass.setBounds(689, 224, 138, 25);
		panel_1_1.add(cPass);
		
		JLabel v6 = new JLabel("");
		v6.setBounds(1061, 224, 146, 25);
		panel_1_1.add(v6);
		
		ePassword = new JPasswordField();
		ePassword.setBounds(291, 224, 213, 25);
		panel_1_1.add(ePassword);
		
		eCPassword = new JPasswordField();
		eCPassword.setBounds(838, 224, 213, 25);
		panel_1_1.add(eCPassword);
		
		JLabel lblDateOfJoining = new JLabel("Date Of Joining:");
		lblDateOfJoining.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblDateOfJoining.setBounds(110, 280, 170, 25);
		panel_1_1.add(lblDateOfJoining);
		
		eDoj = new JTextField();
		eDoj.setText(LocalDate.now().toString());
		eDoj.setEditable(false);
		eDoj.setColumns(10);
		eDoj.setBounds(291, 280, 213, 25);
		panel_1_1.add(eDoj);
		
	
		
		JButton btnNewButton = new JButton("Register");
		btnNewButton.setBounds(237, 344, 172, 37);
		panel_1_1.add(btnNewButton);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				String name=eName.getText();
				String uname=eUsername.getText();
				String phone=ePhone.getText();
				String address=eAddress.getText();
				String password=ePassword.getText();
				String cpassword=eCPassword.getText();
				
				String todayDoj = eDoj.getText(); 
				
				if(name.equals(""))
				{
					v1.setText("This field is required");
				}
				
				else if(uname.equals(""))
				{
					v2.setText("This field is required");
				}
				
				else if(phone.equals(""))
				{
					v3.setText("This field is required");
				}
				
				else if(phone.length() != 10)
				{
					v3.setText("Please enter valid phone no");
				}
				
				else if(address.equals(""))
				{
					v4.setText("This field is required");
				}
				
				else if(password.equals(""))
				{
					v5.setText("This field is required");
				}
				
				else if(cpassword.equals(""))
				{
					v6.setText("This field is required");
				}
				
				else if(!password.equals(cpassword))
				{
					JOptionPane.showMessageDialog(null,"Password Mismatch, please try again");
				}
				
				else
				{
					BillingExecutive BillingExecutive=new BillingExecutive(name,phone,uname,password,address);
					BillingExecutive.setDoj(todayDoj);
					BillingExecutive.setStatus(IsACTIVE.ACTIVE.value());
					boolean flag=new BillingExecutiveDaoImp().addBillingExecutive(BillingExecutive);
					
					if(flag==true)
					{
						eId.setText("");
						eName.setText("");
						ePhone.setText("");
						eDoj.setText("");
						eAddress.setText("");
						ePassword.setText("");
						eCPassword.setText("");
						JOptionPane.showMessageDialog(null,"Registered Successfully as "+name +"as BillingExecutive");
					}
					
					else
					{
						JOptionPane.showMessageDialog(null,"Failed to register BillingExecutive, Please try again.");
					}
					
				}
					
				
			
			}
		});
		btnNewButton.setForeground(new Color(32, 178, 170));
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnNewButton.setBackground(Color.WHITE);
		
		JButton getbutton = new JButton("Get Executive");
		getbutton.setBounds(427, 344, 192, 37);
		panel_1_1.add(getbutton);
		getbutton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				
				String id = eId.getText();
				
				if(id == null || id.equals("")) {
					JOptionPane.showMessageDialog(null,"Enter Billing Executive Id to Fetch the Executive.");	
				}
				
				else if(eId.getText().equals(""))
				{
				    JOptionPane.showMessageDialog(null,"Enter Executive Id to Fetch the Executive.");	
				}
				
				else
				{
					
					int waiterId=Integer.parseInt(id);
					BillingExecutive w=new BillingExecutiveDaoImp().getBillingExecutive(waiterId);
					
					if(w==null)
					{
						JOptionPane.showMessageDialog(null,"No BillingExecutive available with this id.");	
					}
					
					else
					{
						eId.setText(id);
						eName.setText(w.getName());
						ePhone.setText(w.getPhone());
						eDoj.setText(w.getDoj());
						eAddress.setText(w.getAddress());
						eUsername.setText(w.getUsername());
					}
				
				}
				
				
			}
		});
		getbutton.setForeground(new Color(32, 178, 170));
		getbutton.setFont(new Font("Tahoma", Font.BOLD, 20));
		getbutton.setBackground(Color.WHITE);
		
		JButton btnUpdateFood = new JButton("UPDATE Executive");
		btnUpdateFood.setBounds(637, 344, 223, 37);
		panel_1_1.add(btnUpdateFood);
		btnUpdateFood.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				String id=eId.getText();
				
				if(id.equals(""))
				{
					JOptionPane.showMessageDialog(null, "Enter Executive Id:)");
                    return;
				}
				
				BillingExecutive executive = new BillingExecutiveDaoImp().getBillingExecutive(Integer.parseInt(id));

				String name=eName.getText();
				String uname=eUsername.getText();
				String phone=ePhone.getText();
				String address=eAddress.getText();
				
				
				String todayDoj = eDoj.getText(); 
				
				if(name.equals(""))
				{
					v1.setText("This field is required");
				}
				
				else if(uname.equals(""))
				{
					v2.setText("This field is required");
				}
				
				else if(phone.equals(""))
				{
					v3.setText("This field is required");
				}
				
				else if(phone.length() != 10)
				{
					v3.setText("Please enter valid phone no");
				}
				
				else if(address.equals(""))
				{
					v4.setText("This field is required");
				}
				
				else
				{
					BillingExecutive BillingExecutive=new BillingExecutive(name,phone,uname,executive.getPassword(),address);
					BillingExecutive.setId(Integer.parseInt(id));
					BillingExecutive.setDoj(todayDoj);
					BillingExecutive.setStatus(IsACTIVE.ACTIVE.value());
					boolean flag=new BillingExecutiveDaoImp().updateBillingExecutive(BillingExecutive);
					
					if(flag==true)
					{
						eId.setText("");
						eName.setText("");
						ePhone.setText("");
						eDoj.setText("");
						eAddress.setText("");
						ePassword.setText("");
						eCPassword.setText("");
						eUsername.setText("");
						JOptionPane.showMessageDialog(null,"updated Successfully");
					}
					
					else
					{
						JOptionPane.showMessageDialog(null,"Failed to update BillingExecutive, Please try again.");
					}
					
				}
				
			}
		});
		btnUpdateFood.setForeground(new Color(32, 178, 170));
		btnUpdateFood.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnUpdateFood.setBackground(Color.WHITE);
		
		JButton btnDeleteFood = new JButton("DELETE BillingExecutive");
		btnDeleteFood.setBounds(882, 344, 192, 37);
		panel_1_1.add(btnDeleteFood);
		btnDeleteFood.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				String id=eId.getText();
				
				if(id.equals(""))
				{
					JOptionPane.showMessageDialog(null, "Enter Waiter Id:)");
				}
				
				else
				{

					boolean flag=new BillingExecutiveDaoImp().deleteBillingExecutive(Integer.parseInt(id));
					
					if(flag==true)
					{
						eId.setText("");
						eName.setText("");
						ePhone.setText("");
						eDoj.setText("");
						eAddress.setText("");
						ePassword.setText("");
						eCPassword.setText("");
						eUsername.setText("");
						
						JOptionPane.showMessageDialog(null,"BillingExecutive deleted successfully.");
					}
					
					else
					{
						JOptionPane.showMessageDialog(null,"Failed to delete BillingExecutive.");
					}
					
				}
			}
		});
		btnDeleteFood.setForeground(new Color(32, 178, 170));
		btnDeleteFood.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnDeleteFood.setBackground(Color.WHITE);
		
		JButton btnDeleteFood_1 = new JButton("Activate BillingExecutive");
		btnDeleteFood_1.setBounds(291, 417, 328, 37);
		panel_1_1.add(btnDeleteFood_1);
		btnDeleteFood_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String id=eId.getText();
				
				if(id == null || id.equals("")) {
					JOptionPane.showMessageDialog(null,"Enter Billing Executive Id to Fetch the Executive.");	
				    return;
				}
			
				int waiterId = Integer.parseInt(id);
				
				BillingExecutive waiter = new BillingExecutiveDaoImp().getBillingExecutive(waiterId);
				
				if(waiter.getStatus().equals(IsACTIVE.ACTIVE.value())) {
					JOptionPane.showMessageDialog(null,"Waiter already active.");
					return;
				}

				boolean flag=new BillingExecutiveDaoImp().updateBillingExecutiveStatus(IsACTIVE.ACTIVE.value(), waiterId);
				
				if(flag==true)
				{
					eId.setText("");
					eName.setText("");
					ePhone.setText("");
					eDoj.setText("");
					eAddress.setText("");
					ePassword.setText("");
					eCPassword.setText("");
					eUsername.setText("");
					
					JOptionPane.showMessageDialog(null,"BillingExecutive Activated successfully.");
				}
				
				else
				{
					JOptionPane.showMessageDialog(null,"Failed to activate BillingExecutive.");
				}
				
			}
		});
		btnDeleteFood_1.setForeground(new Color(32, 178, 170));
		btnDeleteFood_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnDeleteFood_1.setBackground(Color.WHITE);
		
		JButton btnDeleteFood_1_1 = new JButton("De-Activate BillingExecutive");
		btnDeleteFood_1_1.setBounds(658, 417, 342, 37);
		panel_1_1.add(btnDeleteFood_1_1);
		btnDeleteFood_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				
				String id=eId.getText();
				
				if(id == null || id.equals("")) {
					JOptionPane.showMessageDialog(null,"Enter Billing Executive Id to Fetch the Executive.");	
				    return;
				}
			
				int waiterId = Integer.parseInt(id);
				
				BillingExecutive waiter = new BillingExecutiveDaoImp().getBillingExecutive(waiterId);
				
				if(waiter.getStatus().equals(IsACTIVE.IN_ACTIVE.value())) {
					JOptionPane.showMessageDialog(null,"BillingExecutive already inactive.");
					return;
				}

				boolean flag=new BillingExecutiveDaoImp().updateBillingExecutiveStatus(IsACTIVE.IN_ACTIVE.value(), waiterId);
				
				if(flag==true)
				{
					eId.setText("");
					eName.setText("");
					ePhone.setText("");
					eDoj.setText("");
					eAddress.setText("");
					ePassword.setText("");
					eCPassword.setText("");
					eUsername.setText("");
					
					JOptionPane.showMessageDialog(null,"BillingExecutive de-Activated successfully.");
				}
				
				else
				{
					JOptionPane.showMessageDialog(null,"Failed to deactivate BillingExecutive.");
				}
				
			
			}
		});
		btnDeleteFood_1_1.setForeground(new Color(32, 178, 170));
		btnDeleteFood_1_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnDeleteFood_1_1.setBackground(Color.WHITE);
		
		
	}
}
