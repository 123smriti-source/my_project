package com.restaurant.dao;

import java.util.List;

import com.restaurant.pojo.BillingExecutive;

public interface BillingExecutiveDao {
	
	boolean addBillingExecutive(BillingExecutive a);
    BillingExecutive getBillingExecutive(String username,String password);
    BillingExecutive getBillingExecutive(int id);
    List<BillingExecutive> getAllBillingExecutive();
    boolean updateBillingExecutiveStatus(String status, int BillingExecutiveId); 
    boolean updateBillingExecutive(BillingExecutive BillingExecutive);
    boolean deleteBillingExecutive(int BillingExecutiveId);

}
