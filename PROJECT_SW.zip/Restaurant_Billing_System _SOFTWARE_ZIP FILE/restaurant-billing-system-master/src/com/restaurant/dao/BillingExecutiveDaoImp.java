package com.restaurant.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.restaurant.pojo.BillingExecutive;
import com.restaurant.utility.Constants.IsACTIVE;
import com.restaurant.utility.DBUtility;

public class BillingExecutiveDaoImp implements BillingExecutiveDao {
	
	String str;
	PreparedStatement stmt;
	ResultSet rs;
	int row=0;
	BillingExecutive b;
	static Connection con=DBUtility.connection();

	@Override
	public boolean addBillingExecutive(BillingExecutive a) {
		str="insert into BillingExecutive(name,username,phone,address,password, status, doj) values(?,?,?,?,?,?,?)";
    	try
    	{
    	stmt=con.prepareStatement(str);
    	stmt.setString(1,a.getName());
    	stmt.setString(2,a.getUsername());
    	stmt.setString(3,a.getPhone());
    	stmt.setString(4,a.getAddress());
    	stmt.setString(5,a.getPassword());
    	stmt.setString(6,a.getStatus());
    	stmt.setString(7,a.getDoj());
    	
    	row=stmt.executeUpdate();   //return type of executeupdate is int, it returns ROWS affected in DATABASE
    	
    	}
    	catch(SQLException e)
    	{
    		e.printStackTrace();
    	}
    	if(row>0)
    		return true;
    	else
    		return false;
		
	}

	@Override
	public BillingExecutive getBillingExecutive(String username, String password) {
		str="select * from BillingExecutive where username=? and password=? and status='"+IsACTIVE.ACTIVE.value()+"'";
		try
		{
			stmt=con.prepareStatement(str);
			stmt.setString(1,username);
			stmt.setString(2,password);
			rs=stmt.executeQuery();
			while(rs.next())
			{
				b = new BillingExecutive(rs.getString("name"),rs.getString("phone"),rs.getString("username"),rs.getString("password"),rs.getString("address"));
				b.setId(rs.getInt("id"));
				b.setStatus(rs.getString("status"));
				b.setDoj(rs.getString("doj"));
			}
		}
		
		catch(SQLException e)
      	{
      		e.printStackTrace();
      	}
		
		return b;
	}

	@Override
	public BillingExecutive getBillingExecutive(int id) {
		str="select * from BillingExecutive where id="+id;
		try
		{
			stmt=con.prepareStatement(str);
			
			rs=stmt.executeQuery();
			while(rs.next())
			{
				b = new BillingExecutive(rs.getString("name"),rs.getString("phone"),rs.getString("username"),rs.getString("password"),rs.getString("address"));
				b.setId(rs.getInt("id"));
				b.setStatus(rs.getString("status"));
				b.setDoj(rs.getString("doj"));
			}
		}
		
		catch(SQLException e)
      	{
      		e.printStackTrace();
      	}
		
		return b;
	}

	@Override
	public List<BillingExecutive> getAllBillingExecutive() {
		str="select * from BillingExecutive";
		List<BillingExecutive> li=new ArrayList<>();
		try
		{
			stmt=con.prepareStatement(str);
			rs=stmt.executeQuery();
			while(rs.next())
			{

				b = new BillingExecutive(rs.getString("name"),rs.getString("phone"),rs.getString("username"),rs.getString("password"),rs.getString("address"));
				b.setId(rs.getInt("id"));
				b.setStatus(rs.getString("status"));
				b.setDoj(rs.getString("doj"));
			
		        li.add(b);
		        
				
			}
		}
		
		catch(SQLException e)
      	{
      		e.printStackTrace();
      	}
		
		return li;

		
	}

	@Override
	public boolean updateBillingExecutiveStatus(String status, int BillingExecutiveId) {
		str="update BillingExecutive set status=? where id=?";
    	try
    	{
    	stmt=con.prepareStatement(str);
    	stmt.setString(1,status);
    	stmt.setInt(2,BillingExecutiveId);
    	
    	row=stmt.executeUpdate();   //return type of executeupdate is int, it returns ROWS affected in DATABASE
    	
    	}
    	catch(SQLException e)
    	{
    		e.printStackTrace();
    	}
    	if(row>0)
    		return true;
    	else
    		return false;
	}

	@Override
	public boolean updateBillingExecutive(BillingExecutive BillingExecutive) {
		str="update BillingExecutive set name=?, address=?, phone=? where id=?";
    	try
    	{
    	stmt=con.prepareStatement(str);
    	stmt.setString(1,BillingExecutive.getName());
    	stmt.setString(2,BillingExecutive.getAddress());
    	stmt.setString(3,BillingExecutive.getPhone());
    	stmt.setInt(4,BillingExecutive.getId());	
    	
    	row=stmt.executeUpdate();   //return type of executeupdate is int, it returns ROWS affected in DATABASE
    	
    	}
    	catch(SQLException e)
    	{
    		e.printStackTrace();
    	}
    	if(row>0)
    		return true;
    	else
    		return false;
	}

	@Override
	public boolean deleteBillingExecutive(int BillingExecutiveId) {
        str="delete from BillingExecutive where id=?";
        try
      	{
      	stmt=con.prepareStatement(str);
      	stmt.setInt(1,BillingExecutiveId);
        row=stmt.executeUpdate();   //return type of executeupdate is int, it returns ROWS affected in DATABASE
      	}
      	catch(SQLException e)
      	{
      		e.printStackTrace();
      	}
      	if(row>0)
      		return true;
      	else
      		return false;
          
	}

}
