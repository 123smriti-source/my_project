package com.restaurant.utility;

public class Constants {
	
	public enum IsACTIVE {
		IN_ACTIVE("InActive"),
		ACTIVE("Active");
		
		private String status;

	    private IsACTIVE(String status) {
	      this.status = status;
	    }

	    public String value() {
	      return this.status;
	    }
	     
	}

}
